//: Playground - noun: a place where people can play

class Giant {
    var name: String
    var weight: Double
    let homePlanet: String
    
    init(name: String, weight: Double, homePlanet: String) {
        self.name = name
        self.weight = weight
        self.homePlanet = homePlanet
    }
}

let fred = Giant(name: "Fred", weight: 340.0, homePlanet: "Earth")

fred.name = "Brick"
fred.weight = 999.2
//fred.homePlanet = "Mars"

// Question 1
// no, because homePlanet is a let constant.


// Question 2
// Yes, by changing homePlanet to a var.


struct Alien {
    var name: String
    var height: Double
    var homePlanet: String
}

var bilbo = Alien(name: "Bilbo", height: 1.67, homePlanet: "Venus")

bilbo.name = "Jake"
bilbo.height = 1.42
bilbo.homePlanet = "Saturn"


// Question 3
// No, because bilbo is a let constant.

// Question 4
// Yes, by changing the declaration of bilbo to var.


let edgar = Giant(name: "Edgar", weight: 520.0, homePlanet: "Earth")
let jason = edgar
jason.name = "Jason"

// Question 5
// They will both be Jason.


var charles = Alien(name: "Charles", height: 2.25, homePlanet: "Pluto")
var charlesFromJupiter = charles
charlesFromJupiter.homePlanet = "Jupiter"

// Question 6
// charles.homePlanet will be Pluto, charlesFromJupiter will be Jupiter, because charlesFromJupiter is a copy of charles, as opposed to a reference.


struct BankAccount {
    var owner: String
    var balance: Double
    
    mutating func deposit(_ amount: Double) {
        balance += amount
    }
    
    mutating func withdraw(_ amount: Double) {
        balance -= amount
    }
}

// Question 7
// Because the functions need to be mutating.


// Question 8
// Done.


var joeAccount = BankAccount(owner: "Joe", balance: 100.0)
var joeOtherAccount = joeAccount
joeAccount.withdraw(50.0)

// Question 9
// joeAccount will be 50.0, joeOtherAccount will be 100. BankAccount is a struct, and instances are copies.


class MusicLibrary {
    var tracks: [String]
    
    init() {
        tracks = []
    }
    
    func add(track: String) {
        tracks.append(track)
    }
}


let library1 = MusicLibrary()
library1.add(track: "Michelle")
library1.add(track: "Voodoo Child")
let library2 = library1
library2.add(track: "Come As You Are")

// Question 10
// Because tracks is a MusicLibrary.tracks is a var, the songs will get added to library1. Becauase it is a class and not a struct, library1 will be updated when library2 is, because they are references to the same thing. Both libraries will have all three songs.
